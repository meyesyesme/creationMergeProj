//
//  ViewController.swift
//  CamMergingEditsWorkProj
//
//  Created by  on 06/11/2020.
//

import UIKit
import Foundation
import AVFoundation
import MobileCoreServices

class ViewController: UIViewController, UINavigationControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .black
        
        setupChooseMediaBtns()
        setupSpeedBtn()
        
        setupMergeBtn()
        
        chooseMediaBtn1.tag = 1
        chooseMediaBtn2.tag = 1
        chooseMediaBtn3.tag = 1
        speedBtn.tag = 2
        mergeBtn.tag = 3
        
        addTargetsToP3Buttons()
    }
    
    func addTargetsToP3Buttons() {
        
        let arrayOfButtons = [chooseMediaBtn1,chooseMediaBtn2,chooseMediaBtn3,speedBtn,mergeBtn]
        
        for button in arrayOfButtons {
            button.addTarget(self, action: #selector(buttonTouchUpInside), for: [.touchUpInside])
        }
    }
    
    let chooseMediaBtn1 = UIButton()
    let chooseMediaBtn2 = UIButton()
    let chooseMediaBtn3 = UIButton()
    
    var speedBtn = UIButton()
    var speedBtnTextLabel = UILabel()
    
    var mergeBtn = UIButton()
    
    func setupMergeBtn() {
        
        //Btn setup 1:
        view.addSubview(mergeBtn)
        mergeBtn.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            mergeBtn.heightAnchor.constraint(equalToConstant: 150),
            mergeBtn.widthAnchor.constraint(equalToConstant: 150),
            mergeBtn.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            mergeBtn.topAnchor.constraint(equalTo: speedBtnTextLabel.bottomAnchor, constant: 50),
        ])
        
        mergeBtn.backgroundColor = .yellow
        mergeBtn.layer.cornerRadius = 75
        mergeBtn.clipsToBounds = true
        
        mergeBtn.setTitle("Create Video", for: .normal)
        mergeBtn.setTitleColor(.black, for: .normal)
        
    }
    
    func setupSpeedBtn() {
        
        //Btn setup 1:
        view.addSubview(speedBtn)
        speedBtn.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            speedBtn.heightAnchor.constraint(equalToConstant: 40),
            speedBtn.widthAnchor.constraint(equalToConstant: 100),
            speedBtn.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
            speedBtn.topAnchor.constraint(equalTo: chooseMediaBtn3.bottomAnchor, constant: 20),
        ])
        
        speedBtn.backgroundColor = .gray
        speedBtn.setTitle("0.3", for: .normal)
        
        //Label setup"
        view.addSubview(speedBtnTextLabel)
        speedBtnTextLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            //            speedBtnTextLabel.heightAnchor.constraint(equalToConstant: 200),
            speedBtnTextLabel.widthAnchor.constraint(equalToConstant: 250),
            speedBtnTextLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5),
            speedBtnTextLabel.topAnchor.constraint(equalTo: speedBtn.topAnchor, constant: 0),
            speedBtnTextLabel.trailingAnchor.constraint(equalTo: speedBtn.leadingAnchor, constant: -5),
        ])
        
        speedBtnTextLabel.textColor = .white
        speedBtnTextLabel.text = "Tap on the number to change it. The values are: 0,3, 0.5, 1, 2, 3. 0.3 being slowest (slo-mo), 1 being normal speed, and 3 being fastest speed (fast-motion)."
        speedBtnTextLabel.numberOfLines = 0
        speedBtnTextLabel.lineBreakMode = .byWordWrapping
        speedBtnTextLabel.sizeToFit()
        
    }
    
    func setupChooseMediaBtns() {
        
        
        //Btn setup 1:
        view.addSubview(chooseMediaBtn1)
        chooseMediaBtn1.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            chooseMediaBtn1.heightAnchor.constraint(equalToConstant: 40),
            chooseMediaBtn1.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 100),
            chooseMediaBtn1.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100),
            chooseMediaBtn1.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
        ])
        
        chooseMediaBtn1.backgroundColor = .white
        chooseMediaBtn1.setTitle("Choose Vid", for: .normal)
        chooseMediaBtn1.setTitleColor(.black, for: .normal)
        
        //Btn setup 2:
        view.addSubview(chooseMediaBtn2)
        chooseMediaBtn2.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            chooseMediaBtn2.heightAnchor.constraint(equalToConstant: 40),
            chooseMediaBtn2.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 100),
            chooseMediaBtn2.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100),
            chooseMediaBtn2.topAnchor.constraint(equalTo: chooseMediaBtn1.bottomAnchor, constant: 50),
        ])
        
        chooseMediaBtn2.backgroundColor = .white
        chooseMediaBtn2.setTitle("Choose Vid", for: .normal)
        chooseMediaBtn2.setTitleColor(.black, for: .normal)
        
        //Btn setup 3:
        view.addSubview(chooseMediaBtn3)
        chooseMediaBtn3.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            chooseMediaBtn3.heightAnchor.constraint(equalToConstant: 40),
            chooseMediaBtn3.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 100),
            chooseMediaBtn3.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100),
            chooseMediaBtn3.topAnchor.constraint(equalTo: chooseMediaBtn2.bottomAnchor, constant: 50),
        ])
        
        chooseMediaBtn3.backgroundColor = .white
        chooseMediaBtn3.setTitle("Choose Vid", for: .normal)
        chooseMediaBtn3.setTitleColor(.black, for: .normal)
        
    }
    
    func presentImagePicker() {
        imagePickerController = UIImagePickerController()
        imagePickerController!.sourceType = .savedPhotosAlbum
        imagePickerController!.delegate = self
        imagePickerController!.mediaTypes = [kUTTypeMovie as String]
        
        imagePickerController?.videoMaximumDuration = 30
        imagePickerController?.allowsEditing = true
        
        self.present(imagePickerController!, animated: true, completion: nil)
    }
    
    var imagePickerController: UIImagePickerController?
    
    var vidSegmentsArray = [VideoSegment]()
    
}

// new sep 2020 for audio/sounds:
extension ViewController: UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let mediaURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL else { return }
        // You can do whatever youo want here....
        
        print(mediaURL, "this is mediaURL")
        
        print(speedBtn.titleLabel?.text, "<-- speedBtn.titleLabel?.text??")
        let crntTitleText = (speedBtn.titleLabel?.text)!
        let currentSpeedSelectedForThisVideo: Double = Double((crntTitleText))!
        
        print(currentSpeedSelectedForThisVideo, "<-- currentSpeedSelectedForThisVideo")
        
        let newVidSegment = VideoSegment(vidSpeed: currentSpeedSelectedForThisVideo, url: mediaURL)
        vidSegmentsArray.append(newVidSegment)
        
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)    {
        dismiss(animated: true, completion: nil)
    }
    
    
}


extension ViewController {
    
    @objc func buttonTouchUpInside(_ sender: UIButton) { //let go tap
        
        
        switch sender.tag {
        case 1: //send button (share btn)
            
            presentImagePicker()
            
            break;
        case 2: //time
            
            print(speedBtn.titleLabel?.text, "<-- speedBtn.titleLabel")
            let crntSpeed = speedBtn.titleLabel?.text
            if crntSpeed == "0.3" {
                speedBtn.setTitle("0.5", for: .normal)
                
            } else if crntSpeed == "0.5" {
                speedBtn.setTitle("1", for: .normal)
                
            } else if crntSpeed == "1" {
                speedBtn.setTitle("2", for: .normal)
                
            } else if crntSpeed == "2" {
                speedBtn.setTitle("3", for: .normal)
                
            } else if crntSpeed == "3" {
                speedBtn.setTitle("0.3", for: .normal)
                
            }
            
            break;
        case 3: //create video
            
            //:: *** here you put a merge fucntion.. use a merge function here to merge the videos with the speed changes!
            
            break;
        default: ()
            break;
        }
        
    }
    
}


//MARK: -- ALL MERGE FUNCTIONS ARE HERE:
extension ViewController {
    
    static func videoCompositionInstruction(_ track: AVCompositionTrack, asset: AVAsset)
    -> AVMutableVideoCompositionLayerInstruction {
        let instruction = AVMutableVideoCompositionLayerInstruction(assetTrack: track)
        let assetTrack = asset.tracks(withMediaType: .video)[0]
        
        let transform = assetTrack.preferredTransform
        let assetInfo = orientationFromTransform(transform)
        
        var scaleToFitRatio = 1080 / assetTrack.naturalSize.width
        if assetInfo.isPortrait {
            scaleToFitRatio = 1080 / assetTrack.naturalSize.height
            let scaleFactor = CGAffineTransform(scaleX: scaleToFitRatio, y: scaleToFitRatio)
            var finalTransform = assetTrack.preferredTransform.concatenating(scaleFactor)
            //was needed in my case (if video not taking entire screen and leaving some parts black - don't know when actually needed so you'll have to try and see when it's needed)
            if assetInfo.orientation == .rightMirrored || assetInfo.orientation == .leftMirrored {
                finalTransform = finalTransform.translatedBy(x: -transform.ty, y: 0)
            }
            instruction.setTransform(finalTransform, at: CMTime.zero)
        } else {
            let scaleFactor = CGAffineTransform(scaleX: scaleToFitRatio, y: scaleToFitRatio)
            var concat = assetTrack.preferredTransform.concatenating(scaleFactor)
                .concatenating(CGAffineTransform(translationX: 0, y: UIScreen.main.bounds.width / 2))
            if assetInfo.orientation == .down {
                let fixUpsideDown = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
                let windowBounds = UIScreen.main.bounds
                let yFix = assetTrack.naturalSize.height + windowBounds.height
                let centerFix = CGAffineTransform(translationX: assetTrack.naturalSize.width, y: yFix)
                concat = fixUpsideDown.concatenating(centerFix).concatenating(scaleFactor)
            }
            instruction.setTransform(concat, at: CMTime.zero)
        }
        
        return instruction
    }
    
    static func orientationFromTransform(_ transform: CGAffineTransform)
    -> (orientation: UIImage.Orientation, isPortrait: Bool) {
        var assetOrientation = UIImage.Orientation.up
        var isPortrait = false
        if transform.a == 0 && transform.b == 1.0 && transform.c == -1.0 && transform.d == 0 {
            assetOrientation = .right
            isPortrait = true
        } else if transform.a == 0 && transform.b == 1.0 && transform.c == 1.0 && transform.d == 0 {
            assetOrientation = .rightMirrored
            isPortrait = true
        } else if transform.a == 0 && transform.b == -1.0 && transform.c == 1.0 && transform.d == 0 {
            assetOrientation = .left
            isPortrait = true
        } else if transform.a == 0 && transform.b == -1.0 && transform.c == -1.0 && transform.d == 0 {
            assetOrientation = .leftMirrored
            isPortrait = true
        } else if transform.a == 1.0 && transform.b == 0 && transform.c == 0 && transform.d == 1.0 {
            assetOrientation = .up
        } else if transform.a == -1.0 && transform.b == 0 && transform.c == 0 && transform.d == -1.0 {
            assetOrientation = .down
        }
        return (assetOrientation, isPortrait)
    }
    
    
    
    //MARK: -- USAGE EXAMPLE FOR MY CRNT MERGE FUNC
    //    mergeVideosTestSQ(arrayVideos: videosAVAssetArray) { (theURL, error) in
    //        print(theURL, "<-- theURL, error --->?", error)
    //
    //        if theURL != nil {
    //
    //            DispatchQueue.main.async {
    //
    //            }
    //
    //        }
    //
    //    } //end of first merge
    
    func mergeVideosTestSQ(arrayVideos:[VideoSegment], completion:@escaping (URL?, Error?) -> ()) {
        
        let mixComposition = AVMutableComposition()
        
        
        var instructions: [AVMutableVideoCompositionLayerInstruction] = []
        var insertTime = CMTime(seconds: 0, preferredTimescale: 1)
        
        print(arrayVideos, "<- arrayVideos")
        /// for each URL add the video and audio tracks and their duration to the composition
        for videoSegment in arrayVideos {
            
            let sourceAsset = AVAsset(url: videoSegment.videoURL!)
            
            let frameRange = CMTimeRange(start: CMTime(seconds: 0, preferredTimescale: 1), duration: sourceAsset.duration)
            
            guard
                let nthVideoTrack = mixComposition.addMutableTrack(withMediaType: .video, preferredTrackID: Int32(kCMPersistentTrackID_Invalid)),
                let nthAudioTrack = mixComposition.addMutableTrack(withMediaType: .audio, preferredTrackID: Int32(kCMPersistentTrackID_Invalid)), //0 used to be kCMPersistentTrackID_Invalid
                let assetVideoTrack = sourceAsset.tracks(withMediaType: .video).first
            else {
                print("fart didnt work")
                return
            }
            
            var assetAudioTrack: AVAssetTrack?
            assetAudioTrack = sourceAsset.tracks(withMediaType: .audio).first
            print(assetAudioTrack, ",-- assetAudioTrack???", assetAudioTrack?.asset, "<-- hes", sourceAsset)
            
            do {
                
                try nthVideoTrack.insertTimeRange(frameRange, of: assetVideoTrack, at: insertTime)
                try nthAudioTrack.insertTimeRange(frameRange, of: assetAudioTrack!, at: insertTime)
                
                //                    //MY CURRENT SPEED ATTEMPT:
                //                    let newDuration = CMTimeMultiplyByFloat64(frameRange.duration, multiplier: videoSegment.videoSpeed)
                //                    nthVideoTrack.scaleTimeRange(frameRange, toDuration: newDuration)
                //                    nthAudioTrack.scaleTimeRange(frameRange, toDuration: newDuration)
                
                //                    print(insertTime.value, "<-- fiji, newdur --->", newDuration.value, "sourceasset duration--->", sourceAsset.duration.value, "frameRange.duration -->", frameRange.duration.value)
                
                //instructions:
                let nthInstruction = ViewController.videoCompositionInstruction(nthVideoTrack, asset: sourceAsset)
                nthInstruction.setOpacity(0.0, at: CMTimeAdd(insertTime, sourceAsset.duration)) //sourceasset.duration
                
                instructions.append(nthInstruction)
                insertTime = insertTime + sourceAsset.duration //sourceAsset.duration
                
                
                
            } catch {
                DispatchQueue.main.async {
                    print("fart didnt wor2k")
                }
            }
            
        }
        
        
        let mainInstruction = AVMutableVideoCompositionInstruction()
        mainInstruction.timeRange = CMTimeRange(start: CMTime(seconds: 0, preferredTimescale: 1), duration: insertTime)
        
        mainInstruction.layerInstructions = instructions
        
        let mainComposition = AVMutableVideoComposition()
        mainComposition.instructions = [mainInstruction]
        mainComposition.frameDuration = CMTimeMake(value: 1, timescale: 30)
        mainComposition.renderSize = CGSize(width: 1080, height: 1920)
        
        let outputFileURL = URL(fileURLWithPath: NSTemporaryDirectory() + "merge.mp4")
        
        //below to clear the video form docuent folder for new vid...
        let fileManager = FileManager()
        try? fileManager.removeItem(at: outputFileURL)
        
        print("<now will export: 🔥 🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥")
        
        
        /// try to start an export session and set the path and file type
        if let exportSession = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetHighestQuality) { //DOES NOT WORK WITH AVAssetExportPresetPassthrough
            exportSession.outputFileType = .mov
            exportSession.outputURL = outputFileURL
            exportSession.videoComposition = mainComposition
            exportSession.shouldOptimizeForNetworkUse = true
            
            /// try to export the file and handle the status cases
            exportSession.exportAsynchronously {
                if let url = exportSession.outputURL{
                    completion(url, nil)
                }
                if let error = exportSession.error {
                    completion(nil, error)
                }
            }
            
        }
        
    }
    
    
    //MARK: -- FOR TESTING YOU SHOULD SAVE THE VIDEO TO YOUR PHONE ONCE YOU HAVE THE FINAL VIDEO (merged and with the speed changes) URL
    func saveVideoToPhone(videoURL: URL) {
        
        UISaveVideoAtPathToSavedPhotosAlbum((videoURL.path), self, #selector(self.media(_:didFinishSavingWithError:contextInfo:)), nil)
        
    }
    
    //MARK: - Add Video to Camera Roll
    @objc func media(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error { //could not save
            print("issue saving the video to phone")
            
        } else { //saved
            print("svaed to phoen :)")
            
        }
    }
    
    
}
