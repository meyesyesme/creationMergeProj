//
//  VideoSegment.swift
//  CamMergingEditsWorkProj
//
//  Created by  on 07/11/2020.
//

import Foundation
import UIKit

class VideoSegment: NSObject {
    
    var videoSpeed: Double?
    var videoURL: URL?
    
    init(vidSpeed: Double, url: URL) {
        videoSpeed = vidSpeed
        videoURL = url
    }
    
}
